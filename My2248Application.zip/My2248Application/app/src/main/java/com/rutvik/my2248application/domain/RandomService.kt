package com.rutvik.my2248application.domain

import com.rutvik.my2248application.util.Constants
import kotlin.random.Random

class RandomService {
    fun generateTileValue(): Int {
        val r = Random.nextFloat()
        return when {
            r < Constants.PROB_TWO -> Constants.TILE_VALUE_TWO
            r < Constants.PROB_FOUR -> Constants.TILE_VALUE_FOUR
            else -> Constants.TILE_VALUE_EIGHT
        }
    }
}
