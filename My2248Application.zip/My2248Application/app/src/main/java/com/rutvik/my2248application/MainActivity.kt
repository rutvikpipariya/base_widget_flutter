package com.rutvik.my2248application

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.rutvik.my2248application.ui.screens.GameScreen
import com.rutvik.my2248application.ui.theme.My2248ApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            My2248ApplicationTheme(dynamicColor = false) {
                GameScreen()
            }
        }
    }
}
