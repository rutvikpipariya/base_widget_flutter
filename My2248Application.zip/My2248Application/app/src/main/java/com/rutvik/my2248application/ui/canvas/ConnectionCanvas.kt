package com.rutvik.my2248application.ui.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import com.rutvik.my2248application.model.Tile
import com.rutvik.my2248application.util.GameColors

@Composable
fun ConnectionCanvas(
    selectedTiles: List<Tile>,
    tileSize: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (selectedTiles.size < 2) return@Canvas

        val centers = selectedTiles.map { tile ->
            Offset(
                x = tile.col * tileSize + tileSize / 2f,
                y = tile.row * tileSize + tileSize / 2f
            )
        }

        for (i in 0 until centers.size - 1) {
            drawLine(
                color = GameColors.connectionLine,
                start = centers[i],
                end = centers[i + 1],
                strokeWidth = tileSize * 0.18f,
                cap = StrokeCap.Round
            )
        }

        // Dots at each center
        centers.forEach { center ->
            drawCircle(
                color = GameColors.connectionLine,
                radius = tileSize * 0.12f,
                center = center
            )
        }
    }
}
