package com.rutvik.my2248application.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rutvik.my2248application.model.Tile
import com.rutvik.my2248application.util.GameColors
import com.rutvik.my2248application.util.tileLabel

@Composable
fun TileView(
    tile: Tile,
    isNew: Boolean,
    modifier: Modifier = Modifier
) {
    val tileColor = GameColors.tileColor(tile.value)
    val textColor = GameColors.tileTextColor(tile.value)

    // Selection scale
    val targetScale = when {
        tile.selected -> 1.12f
        isNew -> 0f
        else -> 1f
    }
    val scale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(durationMillis = 150),
        label = "tileScale"
    )

    // Spawn animation: start at 0, animate to 1
    var spawnScale by remember(tile.id) { mutableFloatStateOf(if (isNew) 0f else 1f) }
    LaunchedEffect(isNew) {
        if (isNew) spawnScale = 1f
    }
    val resolvedSpawnScale by animateFloatAsState(
        targetValue = spawnScale,
        animationSpec = tween(durationMillis = 250),
        label = "spawnScale"
    )

    val finalScale = if (isNew) resolvedSpawnScale else scale

    val shape = RoundedCornerShape(12.dp)
    val borderModifier = if (tile.selected) {
        Modifier.border(width = 2.dp, color = GameColors.selectionBorder, shape = shape)
    } else {
        Modifier
    }

    Surface(
        modifier = modifier
            .scale(finalScale)
            .then(borderModifier)
            .shadow(elevation = if (tile.selected) 8.dp else 2.dp, shape = shape),
        shape = shape,
        color = tileColor,
        tonalElevation = 0.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = tile.value.tileLabel(),
                color = textColor,
                fontSize = when {
                    tile.value >= 10000 -> 14.sp
                    tile.value >= 1000 -> 16.sp
                    tile.value >= 100 -> 20.sp
                    else -> 24.sp
                },
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun EmptyTileView(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = GameColors.tileEmpty,
        tonalElevation = 0.dp
    ) {}
}
