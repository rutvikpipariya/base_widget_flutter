package com.rutvik.my2248application.domain

import com.rutvik.my2248application.model.Tile

class MergeService {

    fun calculateMergedValue(tiles: List<Tile>): Int {
        var result = tiles.first().value
        repeat(tiles.size - 1) { result *= 2 }
        return result
    }

    /** Removes all selected tiles except the last, updates last tile's value. */
    fun applyMerge(
        board: List<List<Tile?>>,
        selected: List<Tile>,
        mergedValue: Int
    ): List<List<Tile?>> {
        val last = selected.last()
        var updated = board
        selected.dropLast(1).forEach { tile ->
            updated = updated.mapIndexed { r, row ->
                row.mapIndexed { c, cell ->
                    if (r == tile.row && c == tile.col) null else cell
                }
            }
        }
        // Update last tile value and clear selection flag
        updated = updated.mapIndexed { r, row ->
            row.mapIndexed { c, cell ->
                if (r == last.row && c == last.col) cell?.copy(value = mergedValue, selected = false, isAnimating = false)
                else cell?.copy(selected = false, isAnimating = false)
            }
        }
        return updated
    }
}
