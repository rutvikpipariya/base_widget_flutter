package com.rutvik.my2248application.domain

import com.rutvik.my2248application.model.Tile
import com.rutvik.my2248application.util.Constants

class GravityService {

    /** Compacts each column downward; empty cells float to the top. */
    fun applyGravity(board: List<List<Tile?>>): List<List<Tile?>> {
        val size = Constants.BOARD_SIZE
        val result: Array<Array<Tile?>> = Array(size) { arrayOfNulls(size) }

        for (col in 0 until size) {
            val tiles = mutableListOf<Tile>()
            for (row in 0 until size) {
                board[row][col]?.let { tiles.add(it) }
            }
            // fill from bottom, update row indices
            var destRow = size - 1
            for (tile in tiles.reversed()) {
                result[destRow][col] = tile.copy(row = destRow)
                destRow--
            }
        }

        return result.map { it.toList() }
    }

    /** Fills nulls with spawned tiles (caller provides tile factory). */
    fun fillEmpty(
        board: List<List<Tile?>>,
        spawn: (row: Int, col: Int) -> Tile
    ): List<List<Tile?>> =
        board.mapIndexed { r, row ->
            row.mapIndexed { c, cell ->
                cell ?: spawn(r, c)
            }
        }
}
