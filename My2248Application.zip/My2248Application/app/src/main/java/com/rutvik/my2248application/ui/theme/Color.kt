package com.rutvik.my2248application.ui.theme

import androidx.compose.ui.graphics.Color

val GameDark = Color(0xFF1A1A2E)
val GameSurface = Color(0xFF16213E)
val GameAccent = Color(0xFFFFD700)
