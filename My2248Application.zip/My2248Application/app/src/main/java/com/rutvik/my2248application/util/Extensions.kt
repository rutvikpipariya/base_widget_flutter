package com.rutvik.my2248application.util

import com.rutvik.my2248application.model.Tile
import kotlin.math.abs

fun Tile.isNeighborOf(other: Tile): Boolean =
    abs(this.row - other.row) <= 1 &&
    abs(this.col - other.col) <= 1 &&
    !(this.row == other.row && this.col == other.col)

fun Int.tileLabel(): String = when {
    this >= 1000 -> "${this / 1000}K"
    else -> this.toString()
}
