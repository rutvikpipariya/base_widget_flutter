package com.rutvik.my2248application.viewmodel

import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rutvik.my2248application.domain.BoardService
import com.rutvik.my2248application.domain.GravityService
import com.rutvik.my2248application.domain.MergeService
import com.rutvik.my2248application.domain.RandomService
import com.rutvik.my2248application.model.Tile
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameUiState(
    val board: List<List<Tile?>> = emptyList(),
    val selectedTiles: List<Tile> = emptyList(),
    val score: Int = 0,
    val highScore: Int = 0,
    val isGameOver: Boolean = false,
    val isMerging: Boolean = false,
    val lastMergedValue: Int = 0,
    val newTileIds: Set<Long> = emptySet()
)

class GameViewModel : ViewModel() {

    private val randomService = RandomService()
    private val boardService = BoardService(randomService)
    private val mergeService = MergeService()
    private val gravityService = GravityService()

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState = _uiState.asStateFlow()

    // Tile pixel size set by the UI once layout is known
    private var tileSize: Float = 0f

    init {
        startNewGame()
    }

    fun startNewGame() {
        val board = boardService.generateBoard()
        _uiState.value = GameUiState(
            board = board,
            highScore = _uiState.value.highScore
        )
    }

    fun setBoardMetrics(tilePixelSize: Float) {
        tileSize = tilePixelSize
    }

    // ── Drag handling ─────────────────────────────────────────────────────────

    fun onDragStart(position: Offset) {
        if (_uiState.value.isMerging) return
        val tile = tileAt(position) ?: return
        selectTile(tile)
    }

    fun onDrag(position: Offset) {
        if (_uiState.value.isMerging) return
        val state = _uiState.value
        if (state.selectedTiles.isEmpty()) return
        val candidate = tileAt(position) ?: return
        val last = state.selectedTiles.last()

        // Allow going back one step (undo last selection)
        if (state.selectedTiles.size >= 2) {
            val secondLast = state.selectedTiles[state.selectedTiles.size - 2]
            if (candidate.row == secondLast.row && candidate.col == secondLast.col) {
                deselectLast()
                return
            }
        }

        if (boardService.isValidNeighbor(last, candidate, state.selectedTiles)) {
            selectTile(candidate)
        }
    }

    fun onDragEnd() {
        val state = _uiState.value
        if (state.isMerging) return
        if (state.selectedTiles.size < 2) {
            clearSelection()
            return
        }
        performMerge()
    }

    fun onDragCancel() = clearSelection()

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun tileAt(position: Offset): Tile? {
        if (tileSize <= 0f) return null
        // position is already in local board coordinates (from detectDragGestures)
        val col = (position.x / tileSize).toInt()
        val row = (position.y / tileSize).toInt()
        if (row < 0 || col < 0 || row >= 5 || col >= 5) return null
        return _uiState.value.board[row][col]
    }

    private fun selectTile(tile: Tile) {
        val updated = _uiState.value.board.mapIndexed { r, row ->
            row.mapIndexed { c, cell ->
                if (r == tile.row && c == tile.col) cell?.copy(selected = true) else cell
            }
        }
        _uiState.update { it.copy(board = updated, selectedTiles = it.selectedTiles + tile) }
    }

    private fun deselectLast() {
        val state = _uiState.value
        val removed = state.selectedTiles.last()
        val updated = state.board.mapIndexed { r, row ->
            row.mapIndexed { c, cell ->
                if (r == removed.row && c == removed.col) cell?.copy(selected = false) else cell
            }
        }
        _uiState.update { it.copy(board = updated, selectedTiles = state.selectedTiles.dropLast(1)) }
    }

    private fun clearSelection() {
        val updated = _uiState.value.board.map { row ->
            row.map { cell -> cell?.copy(selected = false, isAnimating = false) }
        }
        _uiState.update { it.copy(board = updated, selectedTiles = emptyList()) }
    }

    private fun performMerge() {
        viewModelScope.launch {
            val state = _uiState.value
            val selected = state.selectedTiles

            val mergedValue = mergeService.calculateMergedValue(selected)
            val newScore = state.score + mergedValue
            val newHighScore = maxOf(state.highScore, newScore)

            // Mark animating
            _uiState.update { it.copy(isMerging = true) }
            delay(150)

            // Apply merge
            val afterMerge = mergeService.applyMerge(state.board, selected, mergedValue)

            // Apply gravity
            val afterGravity = gravityService.applyGravity(afterMerge)
            delay(100)

            // Spawn new tiles
            val newIds = mutableSetOf<Long>()
            val afterSpawn = gravityService.fillEmpty(afterGravity) { row, col ->
                boardService.spawnTile(row, col).also { newIds.add(it.id) }
            }

            val gameOver = boardService.isBoardFull(afterSpawn) && !boardService.hasValidMoves(afterSpawn)

            _uiState.update {
                it.copy(
                    board = afterSpawn,
                    selectedTiles = emptyList(),
                    score = newScore,
                    highScore = newHighScore,
                    isMerging = false,
                    lastMergedValue = mergedValue,
                    isGameOver = gameOver,
                    newTileIds = newIds
                )
            }

            // Clear new-tile highlight after spawn animation
            delay(300)
            _uiState.update { it.copy(newTileIds = emptySet()) }
        }
    }

    fun dismissGameOver() {
        _uiState.update { it.copy(isGameOver = false) }
    }
}
