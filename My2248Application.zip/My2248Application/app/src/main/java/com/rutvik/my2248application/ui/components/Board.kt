package com.rutvik.my2248application.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.dp
import com.rutvik.my2248application.model.Tile
import com.rutvik.my2248application.ui.canvas.ConnectionCanvas
import com.rutvik.my2248application.util.Constants
import com.rutvik.my2248application.util.GameColors

@Composable
fun Board(
    board: List<List<Tile?>>,
    selectedTiles: List<Tile>,
    newTileIds: Set<Long>,
    onDragStart: (Offset) -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
    onBoardMeasured: (tileSize: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(GameColors.boardBackground)
            .padding(6.dp)
            .onGloballyPositioned { coords ->
                val tileSize = coords.size.width.toFloat() / Constants.BOARD_SIZE
                onBoardMeasured(tileSize)
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset -> onDragStart(offset) },
                    onDrag = { change, _ -> onDrag(change.position) },
                    onDragEnd = { onDragEnd() },
                    onDragCancel = { onDragCancel() }
                )
            }
    ) {
        val tileSizePx = constraints.maxWidth.toFloat() / Constants.BOARD_SIZE

        TileGrid(
            board = board,
            newTileIds = newTileIds,
            modifier = Modifier.matchParentSize()
        )

        ConnectionCanvas(
            selectedTiles = selectedTiles,
            tileSize = tileSizePx,
            modifier = Modifier.matchParentSize()
        )
    }
}

@Composable
private fun TileGrid(
    board: List<List<Tile?>>,
    newTileIds: Set<Long>,
    modifier: Modifier = Modifier
) {
    Layout(
        modifier = modifier,
        content = {
            board.flatten().forEach { tile ->
                if (tile != null) {
                    TileView(
                        tile = tile,
                        isNew = tile.id in newTileIds,
                        modifier = Modifier.padding(3.dp)
                    )
                } else {
                    EmptyTileView(modifier = Modifier.padding(3.dp))
                }
            }
        }
    ) { measurables, constraints ->
        val size = Constants.BOARD_SIZE
        val cellSize = constraints.maxWidth / size

        val placeables = measurables.map { measurable ->
            measurable.measure(
                constraints.copy(
                    minWidth = cellSize,
                    maxWidth = cellSize,
                    minHeight = cellSize,
                    maxHeight = cellSize
                )
            )
        }

        layout(constraints.maxWidth, constraints.maxHeight) {
            placeables.forEachIndexed { index, placeable ->
                val row = index / size
                val col = index % size
                placeable.place(col * cellSize, row * cellSize)
            }
        }
    }
}
