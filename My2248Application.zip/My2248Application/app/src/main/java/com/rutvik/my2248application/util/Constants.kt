package com.rutvik.my2248application.util

object Constants {
    const val BOARD_SIZE = 5
    const val MIN_CHAIN = 2
    const val PROB_TWO = 0.70f
    const val PROB_FOUR = 0.95f   // cumulative: 0.70 + 0.25
    // above 0.95 → 8
    const val TILE_VALUE_TWO = 2
    const val TILE_VALUE_FOUR = 4
    const val TILE_VALUE_EIGHT = 8
    const val ANIMATION_DURATION_MS = 200
    const val SPAWN_ANIMATION_DURATION_MS = 250
    const val SCORE_ANIMATION_DURATION_MS = 300
}
