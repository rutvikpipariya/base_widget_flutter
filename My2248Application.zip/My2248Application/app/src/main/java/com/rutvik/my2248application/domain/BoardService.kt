package com.rutvik.my2248application.domain

import com.rutvik.my2248application.model.Tile
import com.rutvik.my2248application.util.Constants
import com.rutvik.my2248application.util.isNeighborOf

class BoardService(private val randomService: RandomService) {

    private var nextId = 0L
    private fun newId() = nextId++

    fun generateBoard(): List<List<Tile?>> =
        List(Constants.BOARD_SIZE) { row ->
            List(Constants.BOARD_SIZE) { col ->
                Tile(
                    id = newId(),
                    value = randomService.generateTileValue(),
                    row = row,
                    col = col
                )
            }
        }

    fun getTile(board: List<List<Tile?>>, row: Int, col: Int): Tile? =
        board.getOrNull(row)?.getOrNull(col)

    fun replaceTile(board: List<List<Tile?>>, row: Int, col: Int, tile: Tile?): List<List<Tile?>> =
        board.mapIndexed { r, rowList ->
            rowList.mapIndexed { c, existing ->
                if (r == row && c == col) tile else existing
            }
        }

    /**
     * Validates whether [candidate] can extend the current chain.
     *
     * - 2nd tile: must match the 1st tile's value (initial same-value pair required).
     * - 3rd tile onward: same value as last OR double the last value.
     *
     * Valid:   2→2  |  2→2→2→2  |  2→2→4→8  |  2→2→2→4→8
     * Invalid: 2→4  |  2→4→8
     */
    fun isValidNeighbor(last: Tile, candidate: Tile, selected: List<Tile>): Boolean {
        val valueAllowed = if (selected.size == 1) {
            candidate.value == last.value
        } else {
            candidate.value == last.value || candidate.value == last.value * 2
        }
        return candidate.isNeighborOf(last) &&
            valueAllowed &&
            selected.none { it.row == candidate.row && it.col == candidate.col }
    }

    fun isBoardFull(board: List<List<Tile?>>): Boolean =
        board.all { row -> row.all { it != null } }

    fun hasValidMoves(board: List<List<Tile?>>): Boolean {
        for (row in 0 until Constants.BOARD_SIZE) {
            for (col in 0 until Constants.BOARD_SIZE) {
                val tile = board[row][col] ?: continue
                val neighbors = getNeighborTiles(board, row, col)
                if (neighbors.any { it.value == tile.value }) return true
            }
        }
        return false
    }

    fun getNeighborTiles(board: List<List<Tile?>>, row: Int, col: Int): List<Tile> {
        val result = mutableListOf<Tile>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                board.getOrNull(row + dr)?.getOrNull(col + dc)?.let { result.add(it) }
            }
        }
        return result
    }

    fun spawnTile(row: Int, col: Int): Tile =
        Tile(id = newId(), value = randomService.generateTileValue(), row = row, col = col)
}
