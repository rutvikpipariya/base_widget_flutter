package com.rutvik.my2248application.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rutvik.my2248application.R
import com.rutvik.my2248application.ui.components.Board
import com.rutvik.my2248application.ui.components.GameOverDialog
import com.rutvik.my2248application.ui.components.ScoreView
import com.rutvik.my2248application.util.GameColors
import com.rutvik.my2248application.viewmodel.GameUiState
import com.rutvik.my2248application.viewmodel.GameViewModel

// Breakpoints matching Material3 adaptive guidelines
private val COMPACT_WIDTH  = 600.dp   // phone
private val MEDIUM_WIDTH   = 840.dp   // foldable / small tablet
private val BOARD_MAX_SIZE = 520.dp   // cap board on large screens

@Composable
fun GameScreen(viewModel: GameViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(GameColors.background)
            // safeDrawingPadding covers status bar, navigation bar, AND display
            // cutout in one modifier — required for Android 15 edge-to-edge enforcement.
            .safeDrawingPadding()
    ) {
        val isLandscape = maxWidth > maxHeight

        if (isLandscape) {
            LandscapeLayout(state = state, viewModel = viewModel)
        } else {
            PortraitLayout(state = state, viewModel = viewModel)
        }

        if (state.isGameOver) {
            val highTile = state.board.flatten().filterNotNull().maxOfOrNull { it.value } ?: 0
            GameOverDialog(
                score = state.score,
                highTile = highTile,
                onRestart = { viewModel.startNewGame() },
                onDismiss = { viewModel.dismissGameOver() }
            )
        }
    }
}

// ── Portrait layout ───────────────────────────────────────────────────────────
// Phone:            board fills width up to screen edge minus padding
// Tablet/Foldable:  board capped at BOARD_MAX_SIZE and horizontally centred

@Composable
private fun BoxWithConstraintsScope.PortraitLayout(
    state: GameUiState,
    viewModel: GameViewModel
) {
    val isExpanded = maxWidth >= COMPACT_WIDTH
    val titleFontSize = if (isExpanded) 40.sp else 32.sp
    val verticalContentPadding = if (isExpanded) 20.dp else 12.dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = verticalContentPadding),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.app_title),
                color = GameColors.scoreText,
                fontSize = titleFontSize,
                fontWeight = FontWeight.ExtraBold
            )
            NewGameButton(onClick = { viewModel.startNewGame() })
        }

        Spacer(Modifier.height(12.dp))

        ScoreView(score = state.score, highScore = state.highScore)

        // Push board toward centre of remaining space
        Spacer(Modifier.weight(1f))

        // Board: fills available width on phones; capped + centred on large screens
        Board(
            board = state.board,
            selectedTiles = state.selectedTiles,
            newTileIds = state.newTileIds,
            onDragStart = viewModel::onDragStart,
            onDrag = viewModel::onDrag,
            onDragEnd = viewModel::onDragEnd,
            onDragCancel = viewModel::onDragCancel,
            onBoardMeasured = viewModel::setBoardMetrics,
            modifier = Modifier
                .widthIn(max = BOARD_MAX_SIZE)
                .fillMaxWidth()
        )

        Spacer(Modifier.weight(1f))

        Text(
            text = stringResource(R.string.drag_hint),
            color = GameColors.labelText,
            fontSize = 13.sp
        )

        Spacer(Modifier.height(4.dp))
    }
}

// ── Landscape layout ──────────────────────────────────────────────────────────
// Info panel on the left, square board on the right.
// Board height is capped so the info panel always has enough room.

@Composable
private fun BoxWithConstraintsScope.LandscapeLayout(
    state: GameUiState,
    viewModel: GameViewModel
) {
    // Board size = min(available height, 55 % of available width)
    // This keeps the left panel wide enough on all screen sizes.
    val boardSize = minOf(
        maxHeight - 16.dp,
        maxWidth * 0.55f,
        BOARD_MAX_SIZE
    )

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ── Left info panel ───────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.app_title),
                color = GameColors.scoreText,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(Modifier.height(12.dp))

            // Stacked score boxes suit the narrow landscape sidebar
            ScoreView(
                score = state.score,
                highScore = state.highScore,
                vertical = true
            )

            Spacer(Modifier.height(16.dp))

            NewGameButton(
                onClick = { viewModel.startNewGame() },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            Text(
                text = stringResource(R.string.drag_hint),
                color = GameColors.labelText,
                fontSize = 11.sp
            )
        }

        // ── Board ─────────────────────────────────────────────────────────────
        Board(
            board = state.board,
            selectedTiles = state.selectedTiles,
            newTileIds = state.newTileIds,
            onDragStart = viewModel::onDragStart,
            onDrag = viewModel::onDrag,
            onDragEnd = viewModel::onDragEnd,
            onDragCancel = viewModel::onDragCancel,
            onBoardMeasured = viewModel::setBoardMetrics,
            modifier = Modifier.fillMaxHeight()
        )
    }
}

// ── Shared components ─────────────────────────────────────────────────────────

@Composable
private fun NewGameButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(containerColor = GameColors.tileColor(16))
    ) {
        Text(
            text = stringResource(R.string.new_game_label),
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}
