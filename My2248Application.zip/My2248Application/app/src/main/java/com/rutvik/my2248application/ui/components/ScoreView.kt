package com.rutvik.my2248application.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rutvik.my2248application.R
import com.rutvik.my2248application.util.GameColors

@Composable
fun ScoreView(
    score: Int,
    highScore: Int,
    vertical: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (vertical) {
        Column(
            modifier = modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ScoreBox(label = stringResource(R.string.score_label), value = score, compact = true)
            ScoreBox(label = stringResource(R.string.best_label), value = highScore, compact = true)
        }
    } else {
        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ScoreBox(label = stringResource(R.string.score_label), value = score)
            ScoreBox(label = stringResource(R.string.best_label), value = highScore)
        }
    }
}

@Composable
private fun ScoreBox(
    label: String,
    value: Int,
    compact: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = GameColors.boardBackground,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = if (compact) 16.dp else 24.dp,
                vertical = if (compact) 6.dp else 8.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                color = GameColors.labelText,
                fontSize = if (compact) 11.sp else 12.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            AnimatedContent(
                targetState = value,
                transitionSpec = {
                    slideInVertically { -it } togetherWith slideOutVertically { it }
                },
                label = "scoreAnim"
            ) { animatedValue ->
                Text(
                    text = animatedValue.toString(),
                    color = GameColors.scoreText,
                    fontSize = if (compact) 18.sp else 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
