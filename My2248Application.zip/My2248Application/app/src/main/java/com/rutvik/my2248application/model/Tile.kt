package com.rutvik.my2248application.model

data class Tile(
    val id: Long,
    val value: Int,
    val row: Int,
    val col: Int,
    val selected: Boolean = false,
    val isAnimating: Boolean = false
)
