package com.rutvik.my2248application.util

import androidx.compose.ui.graphics.Color

object GameColors {
    val background = Color(0xFF1A1A2E)
    val boardBackground = Color(0xFF16213E)
    val tileEmpty = Color(0xFF0F3460)

    fun tileColor(value: Int): Color = when (value) {
        2 -> Color(0xFFB0BEC5)
        4 -> Color(0xFF81D4FA)
        8 -> Color(0xFF1E88E5)
        16 -> Color(0xFF43A047)
        32 -> Color(0xFFFB8C00)
        64 -> Color(0xFFE53935)
        128 -> Color(0xFF8E24AA)
        256 -> Color(0xFFEC407A)
        512 -> Color(0xFF00897B)
        else -> Color(0xFFFFD700) // 1024+
    }

    fun tileTextColor(value: Int): Color = when (value) {
        2, 4 -> Color(0xFF1A1A2E)
        else -> Color.White
    }

    val selectionGlow = Color(0xAAFFFFFF)
    val selectionBorder = Color(0xFFFFFFFF)
    val connectionLine = Color(0xCCFFFFFF)
    val scoreText = Color(0xFFFFD700)
    val labelText = Color(0xFFB0BEC5)
}
