# AGENT.md --- Launcher Android (Compose)

> **Mandatory:** Every AI agent MUST read this entire file at the start
> of every task.

------------------------------------------------------------------------

## 0. Agent Workflow

1.  Read `AGENT.md` first.
2.  Explore only the files needed.
3.  Match existing project patterns.
4.  Make the smallest possible change.
5.  Verify before finishing.

------------------------------------------------------------------------

# 1. Project Overview

  Property       Value
  -------------- ---------------------------------------------
  App ID         `com.rp.launcherapp`
  Language       Kotlin only
  UI             Jetpack Compose only (No XML)
  Architecture   MVVM + Clean Architecture
  Min SDK        24
  Target SDK     36
  Compile SDK    37
  Build System   Gradle Kotlin DSL
  UI State       StateFlow
  Async          Kotlin Coroutines
  Persistence    SharedPreferences (PreferenceHelper) + Gson

## Allowed Dependencies

-   AndroidX
-   Jetpack Compose
-   Material 3
-   Lifecycle
-   ViewModel
-   Navigation Compose
-   Kotlin Coroutines
-   Gson

## Forbidden

-   Java
-   XML layouts
-   ViewBinding
-   DataBinding
-   RecyclerView
-   Fragments unless explicitly requested
-   Third-party UI frameworks
-   New dependencies without approval

------------------------------------------------------------------------

# 2. Folder Structure

``` text
app/src/main/java/com/rp/launcherapp/

model/
repository/
viewmodel/
ui/
    screens/
    components/
    navigation/
    theme/
    canvas/
util/
```

UI is written entirely using Compose.

Do not create XML layouts.

Resources are limited to:

-   strings.xml
-   colors.xml
-   themes.xml
-   drawables
-   fonts

------------------------------------------------------------------------

# 3. Architecture Rules

Model - Pure Kotlin data models.

Repository - Data access only. - Returns Kotlin models or Flow.

ViewModel - Holds business logic. - Exposes immutable StateFlow.

UI - Stateless Composables. - Collect state using
collectAsStateWithLifecycle(). - No business logic.

Example:

``` kotlin
private val _uiState = MutableStateFlow(UiState())
val uiState = _uiState.asStateFlow()
```

Activity:

``` kotlin
enableEdgeToEdge()

setContent {
    LauncherTheme {
        MainScreen()
    }
}
```

Lists

-   LazyColumn
-   LazyRow
-   LazyVerticalGrid

Dialogs

-   AlertDialog
-   ModalBottomSheet

Animations

-   Compose Animation APIs

------------------------------------------------------------------------

# 4. Strict Coding Rules

Required

-   Kotlin only
-   Jetpack Compose only
-   Material 3
-   StateFlow
-   Coroutines
-   Immutable UI state
-   val over var

Forbidden

-   Java
-   XML
-   ViewBinding
-   DataBinding
-   findViewById()
-   RecyclerView adapters
-   Wildcard imports
-   !!
-   Business logic inside Composables
-   Hardcoded strings

------------------------------------------------------------------------

# 5. Adding Features

1.  Model
2.  Repository
3.  ViewModel
4.  Composable Screen
5.  Reusable Components
6.  Navigation
7.  Verify

------------------------------------------------------------------------

# 6. Naming

Screens

-   MainScreen.kt

Components

-   AppCard.kt

Dialogs

-   SettingsDialog.kt

Canvas

-   ConnectionCanvas.kt

Theme

-   Theme.kt
-   Color.kt
-   Type.kt

------------------------------------------------------------------------

# 7. Checklist

-   Compose only
-   No XML
-   No Java
-   StateFlow
-   collectAsStateWithLifecycle()
-   Material 3
-   Stateless composables
-   No unnecessary recompositions
-   Business logic only in ViewModel
-   Minimal changes

------------------------------------------------------------------------

# 8. Future Improvements

Do not implement without approval

-   Hilt
-   Room
-   Firebase
-   Play Games Services
-   Cloud Save
-   Dynamic Themes
-   KMP
