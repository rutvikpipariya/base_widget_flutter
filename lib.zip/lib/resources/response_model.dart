class ResponseModel {
  final dynamic data;
  final String? message;
  final int? code;
  final dynamic extra;

  ResponseModel({this.data, this.message, this.code, this.extra});

  factory ResponseModel.fromJson(Map<String, dynamic> json) {
    int? codeValue;
    if (json['code'] != null) {
      if (json['code'] is int) {
        codeValue = json['code'] as int;
      } else if (json['code'] is String) {
        codeValue = int.tryParse(json['code'] as String);
      }
    }

    return ResponseModel(
      data: json['data'],
      message: json['message'],
      code: codeValue,
      extra: json['extra'],
    );
  }

  Map<String, dynamic> toJson() => {
    'data': data,
    'message': message,
    'code': code,
    'extra': extra,
  };
}
