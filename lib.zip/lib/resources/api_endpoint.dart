enum ApiEndpoints {
  login('/helper/helper-onboarding/'),
  signup('/common/create/'),
  interest('/common/validate/'),
  dashboard('/common/resend/');

  const ApiEndpoints(this.path);

  final String path;
}
