import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:untitled/routes/app_pages.dart';
import 'package:untitled/service/shared_pref_service.dart';
import 'package:untitled/utils/constant.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SharedPrefService.init();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  appPrint(SharedPrefService.getToken(AppConstants.accessToken));
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) => GetMaterialApp(
    builder: (context, child) {
      final mediaQuery = MediaQuery.of(context);

      return MediaQuery(
        data: mediaQuery.copyWith(
          textScaler: mediaQuery.textScaler.clamp(
            minScaleFactor: 0.9,
            maxScaleFactor: 0.9,
          ),
          boldText: false,
        ),
        child: child ?? const SizedBox.shrink(),
      );
    },
    debugShowCheckedModeBanner: false,
    initialRoute: Routes.dashboardScreen,
    getPages: AppPages.routes,
  );
}
