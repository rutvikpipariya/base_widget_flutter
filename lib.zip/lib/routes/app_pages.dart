import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:untitled/module/dashboard/screen/dashboard_screen.dart';
import 'package:untitled/module/interest/screen/interest_screen.dart';
import 'package:untitled/module/login/screen/login_screen.dart';
import 'package:untitled/module/signup/screen/sign_up_screen.dart';
import 'package:untitled/module/splash/screen/splash_screen.dart';

part 'app_routes.dart';

class AppPages {
  static const initialScreen = Routes.splashScreen;

  static final routes = [
    GetPage(name: Routes.splashScreen, page: () => const SplashScreen()),
    GetPage(name: Routes.loginScreen, page: () => const LoginScreen()),
    GetPage(name: Routes.signUpScreen, page: () => const SignUpScreen()),
    GetPage(name: Routes.interestScreen, page: () => const InterestScreen()),
    GetPage(name: Routes.dashboardScreen, page: () => const DashboardScreen()),
  ];
}
