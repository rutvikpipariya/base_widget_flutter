part of 'app_pages.dart';

abstract class Routes {
  static const splashScreen = '/splash_screen';
  static const loginScreen = '/login_screen';
  static const signUpScreen = '/signU_up_screen';
  static const interestScreen = '/interest_screen';
  static const dashboardScreen = '/dashboard_screen';
}
