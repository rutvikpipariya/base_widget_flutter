import 'package:flutter/foundation.dart';

class AppConstants {
  static const String accessToken = 'access_token';
}

void appPrint(dynamic data) {
  if (kDebugMode) {
    print(data);
  }
}
