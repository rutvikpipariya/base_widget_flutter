import 'package:flutter/material.dart';

class AppTextStyles {
  static final TextStyle light = TextStyle(
    fontSize: 16,
    fontWeight: .w300,
    color: Colors.black,
    decoration: TextDecoration.none,
  );

  static final TextStyle regular = TextStyle(
    fontSize: 16,
    fontWeight: .w400,
    color: Colors.black,
    decoration: TextDecoration.none,
  );

  static final TextStyle medium = TextStyle(
    fontSize: 16,
    fontWeight: .w500,
    color: Colors.black,
    decoration: TextDecoration.none,
  );

  static final TextStyle semibold = TextStyle(
    fontSize: 16,
    fontWeight: .w600,
    color: Colors.black,
    decoration: TextDecoration.none,
  );

  static final TextStyle bold = TextStyle(
    fontSize: 16,
    fontWeight: .w700,
    color: Colors.black,
    decoration: TextDecoration.none,
  );

  static final TextStyle heavy = TextStyle(
    fontSize: 16,
    fontWeight: .w800,
    color: Colors.black,
    decoration: TextDecoration.none,
  );
}
