import 'package:untitled/resources/api_endpoint.dart';
import 'package:untitled/resources/response_model.dart';
import 'package:untitled/service/api_service.dart';

class DashboardRepository {
  final Api _api = Api();

  Future<ResponseModel> getDashboardData() async {
    try {
      final res = await _api.get(ApiEndpoints.dashboard.path);
      return res;
    } catch (e) {
      rethrow;
    }
  }
}
