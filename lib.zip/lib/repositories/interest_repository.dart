import 'package:untitled/resources/api_endpoint.dart';
import 'package:untitled/resources/response_model.dart';
import 'package:untitled/service/api_service.dart';

class InterestRepository {
  final Api _api = Api();

  Future<ResponseModel> addInterest({
    required String address,
    required String apartment,
    required String postalCode,
    required String state,
    required String city,
    required String country,
    required double latitude,
    required double longitude,
  }) async {
    try {
      final res = await _api.post(
        ApiEndpoints.interest.path,
        data: {
          'address': address,
          'apartment': apartment,
          'postal_code': postalCode,
          'state': state,
          'city': city,
          'country': country,
          'latitude': latitude,
          'longitude': longitude,
        },
      );
      return res;
    } catch (e) {
      rethrow;
    }
  }
}
