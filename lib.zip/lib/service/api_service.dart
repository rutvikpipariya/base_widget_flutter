import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart';
import 'package:untitled/resources/response_model.dart';
import 'package:untitled/service/shared_pref_service.dart';
import 'package:untitled/utils/constant.dart';

class Api {
  final dio = createDio();

  Api._internal();

  static final _singleton = Api._internal();

  static final timeOutDuration = const Duration(seconds: 45);

  static final baseURL = kDebugMode
      ? 'https://dolphin-healthcare-api.digiqt.com'
      : 'https://health-api.joindolphin.com';

  static const contentType = 'application/json';

  factory Api() => _singleton;

  static Dio createDio() {
    final dio = Dio(
      BaseOptions(
        baseUrl: baseURL,
        connectTimeout: timeOutDuration,
        receiveTimeout: timeOutDuration,
        sendTimeout: timeOutDuration,
        contentType: contentType,
        validateStatus: (status) => status != null && status < 500,
      ),
    );
    (dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () {
      final client = HttpClient();
      client.badCertificateCallback = (cert, host, port) => true;
      return client;
    };
    return dio;
  }

  Future<ResponseModel> get(
    String path, {
    Map<String, dynamic>? header,
    Map<String, dynamic>? queryParameters,
    void Function(int, int)? onReceiveProgress,
    bool addRequestInterceptor = true,
    bool tokenRequired = true,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.get(
      options: Options(
        headers: tokenRequired ? finalHeader : header,
        extra: {'showLoader': showLoader},
      ),
      dio.options.baseUrl + path,
      onReceiveProgress: onReceiveProgress,
      queryParameters: queryParameters,
    );
    logFullResponse(res);
    return ResponseModel.fromJson(res.data);
  }

  Future<T> dynamicGet<T>(
    String path, {
    required T Function(Map<String, dynamic>) fromJson,
    Map<String, dynamic>? header,
    Map<String, dynamic>? queryParameters,
    void Function(int, int)? onReceiveProgress,
    bool tokenRequired = true,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.get(
      dio.options.baseUrl + path,
      options: Options(
        headers: tokenRequired ? finalHeader : header,
        extra: {'showLoader': showLoader},
      ),
      onReceiveProgress: onReceiveProgress,
      queryParameters: queryParameters,
    );
    logFullResponse(res);
    final data = res.data as Map<String, dynamic>;
    return fromJson(data);
  }

  Future<ResponseModel> post(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Map<String, dynamic>? header,
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    Duration? timeout,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.post(
      dio.options.baseUrl + path,
      data: data,
      queryParameters: queryParameters,
      options: Options(headers: finalHeader, extra: {'showLoader': showLoader}),
      onReceiveProgress: onReceiveProgress,
      onSendProgress: onSendProgress,
    );
    logFullResponse(res);
    return ResponseModel.fromJson(res.data);
  }

  Future<ResponseModel> delete(
    String path, {
    Map<String, dynamic>? header,
    Map<String, dynamic>? queryParameters,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.delete(
      dio.options.baseUrl + path,
      options: Options(headers: finalHeader, extra: {'showLoader': showLoader}),
      queryParameters: queryParameters,
    );

    if (res.data == null) {
      return ResponseModel(
        code: res.statusCode,
        data: res.data,
        message: res.statusMessage,
        extra: res.extra,
      );
    }
    logFullResponse(res);
    return ResponseModel.fromJson(res.data);
  }

  Future<ResponseModel> postFormData(
    String path, {
    required FormData data,
    Map<String, dynamic>? queryParameters,
    Map<String, dynamic>? header,
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    Duration? timeout,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.post(
      dio.options.baseUrl + path,
      data: data,
      queryParameters: queryParameters,
      options: Options(
        headers: finalHeader,
        sendTimeout: timeout,
        contentType: 'multipart/form-data',
        extra: {'showLoader': showLoader},
      ),
      onReceiveProgress: onReceiveProgress,
      onSendProgress: (sent, total) {
        onSendProgress?.call(sent, total);
      },
    );
    logFullResponse(res);
    return ResponseModel.fromJson(res.data);
  }

  Future<ResponseModel> patch(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Map<String, dynamic>? header,
    void Function(int, int)? onSendProgress,
    void Function(int, int)? onReceiveProgress,
    bool showLoader = true,
  }) async {
    final finalHeader = getHeaders(header);
    final res = await dio.patch(
      dio.options.baseUrl + path,
      data: data,
      queryParameters: queryParameters,
      options: Options(headers: finalHeader, extra: {'showLoader': showLoader}),
      onReceiveProgress: onReceiveProgress,
      onSendProgress: onSendProgress,
    );
    logFullResponse(res);
    return ResponseModel.fromJson(res.data);
  }

  Map<String, dynamic> getHeaders([Map<String, dynamic>? extraHeaders]) {
    final savedToken = SharedPrefService.getToken('access_token');
    final Map<String, dynamic> finalHeader = {
      'Authorization': 'Bearer $savedToken',
      'Content-Type': contentType,
      ...?extraHeaders,
    };
    return finalHeader;
  }

  void logFullResponse(Response response) {
    appPrint('────────── API RESPONSE START ──────────');
    appPrint('URL        : ${response.requestOptions.uri}');
    appPrint('METHOD     : ${response.requestOptions.method}');
    appPrint('STATUS CODE: ${response.statusCode}');
    appPrint('STATUS MSG : ${response.statusMessage}');
    appPrint('HEADERS    : ${response.headers.map}');
    appPrint('EXTRA      : ${response.extra}');
    appPrint('DATA       : ${response.data}');
    appPrint('────────── API RESPONSE END ──────────');
  }
}
