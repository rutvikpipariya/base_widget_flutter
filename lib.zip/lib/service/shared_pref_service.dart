import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefService {
  static SharedPreferences? _prefs;

  static Future init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future setBool(String key, bool value) async {
    await _prefs?.setBool(key, value);
  }

  static bool getBool(String key, {bool defaultValue = false}) =>
      _prefs?.getBool(key) ?? defaultValue;

  static Future setToken(String key, String value) async {
    await _prefs?.setString(key, value);
  }

  static String? getToken(String key) => _prefs?.getString(key);

  static Future clearAll() async {
    await _prefs?.clear();
  }
}
