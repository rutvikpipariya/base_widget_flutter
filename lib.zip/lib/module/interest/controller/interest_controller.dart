import 'package:get/get.dart';

class InterestController extends GetxController {
  static const interests = [
    'Music',
    'Travel',
    'Fitness',
    'Cooking',
    'Reading',
    'Gaming',
    'Movies',
    'Photography',
    'Art',
    'Sports',
    'Technology',
    'Fashion',
  ];

  final selected = <String>{};

  void toggle(String interest) {
    selected.contains(interest)
        ? selected.remove(interest)
        : selected.add(interest);
    update();
  }
}
