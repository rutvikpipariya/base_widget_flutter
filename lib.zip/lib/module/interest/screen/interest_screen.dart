import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:untitled/module/interest/controller/interest_controller.dart';
import 'package:untitled/utils/app_text_styles.dart';

class InterestScreen extends StatelessWidget {
  const InterestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(InterestController());

    return Scaffold(
      appBar: AppBar(title: const Text('Interests')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('What are you into?', style: AppTextStyles.semibold),
            const SizedBox(height: 16),
            GetBuilder<InterestController>(
              builder: (controller) => Wrap(
                spacing: 8,
                runSpacing: 8,
                children: InterestController.interests
                    .map(
                      (interest) => FilterChip(
                        label: Text(interest),
                        selected: controller.selected.contains(interest),
                        onSelected: (_) => controller.toggle(interest),
                      ),
                    )
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
