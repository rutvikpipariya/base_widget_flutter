import 'package:get/get.dart';
import 'package:untitled/routes/app_pages.dart';
import 'package:untitled/service/shared_pref_service.dart';
import 'package:untitled/utils/constant.dart';

class SplashController extends GetxController {
  bool isLoading = true;

  @override
  void onReady() {
    super.onReady();
    checkLogin();
  }

  Future<void> checkLogin() async {
    isLoading = true;
    update();
    
    await Future.delayed(const Duration(seconds: 2));

    final token = SharedPrefService.getToken(AppConstants.accessToken);

    if (token != null && token.isNotEmpty) {
      Get.offAllNamed(Routes.dashboardScreen);
    } else {
      Get.offAllNamed(Routes.loginScreen);
    }

    isLoading = false;
    update();
  }
}
