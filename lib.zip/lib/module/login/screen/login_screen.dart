import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:untitled/widgets/app_textfield_widget.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Login',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              AppTextfieldWidget(
                label: 'Email',
                hintText: 'Please enter email',
              ).paddingSymmetric(vertical: 24),
              AppTextfieldWidget(
                label: 'Password',
                hintText: 'Please enter password',
                isPassword: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
