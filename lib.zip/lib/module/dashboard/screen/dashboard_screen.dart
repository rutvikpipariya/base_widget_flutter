import 'package:flutter/material.dart';
import 'package:untitled/widgets/svg_image_widget.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: SvgImageWidget(asset: 'assets/images/ic_profile.svg'),
      ),
    );
  }
}
