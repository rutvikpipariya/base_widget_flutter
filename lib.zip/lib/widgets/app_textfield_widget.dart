import 'package:flutter/material.dart';
import 'package:get/get_utils/src/extensions/widget_extensions.dart';
import 'package:untitled/utils/app_text_styles.dart';

class AppTextfieldWidget extends StatefulWidget {
  final String label;
  final String hintText;
  final TextEditingController? controller;
  final Widget? suffix;
  final bool readOnly;
  final VoidCallback? onTap;
  final int? maxLength;
  final TextInputType keyboardType;
  final bool isPassword;

  const AppTextfieldWidget({
    super.key,
    required this.label,
    required this.hintText,
    this.controller,
    this.suffix,
    this.readOnly = false,
    this.onTap,
    this.maxLength,
    this.keyboardType = TextInputType.text,
    this.isPassword = false,
  });

  @override
  State<AppTextfieldWidget> createState() => _AppTextfieldWidgetState();
}

class _AppTextfieldWidgetState extends State<AppTextfieldWidget> {
  late bool obscure = widget.isPassword;

  @override
  Widget build(BuildContext context) {
    final suffix = widget.isPassword
        ? IconButton(
            onPressed: () => setState(() => obscure = !obscure),
            icon: Icon(
              obscure ? Icons.visibility_off : Icons.visibility,
              color: Colors.black.withAlpha(120),
            ),
            tooltip: obscure ? 'Show password' : 'Hide password',
          )
        : widget.suffix;

    return Column(
      crossAxisAlignment: .start,
      children: [
        Text(widget.label, style: AppTextStyles.bold.copyWith(fontSize: 14)),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(20),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
            borderRadius: .circular(12),
          ),
          child: TextField(
            readOnly: widget.readOnly,
            keyboardType: widget.keyboardType,
            enableInteractiveSelection: !widget.readOnly,
            controller: widget.controller,
            maxLength: widget.maxLength,
            obscureText: obscure,
            style: AppTextStyles.medium.copyWith(
              fontSize: 14,
              color: Colors.black,
            ),
            decoration: InputDecoration(
              counterText: '',
              hintText: widget.hintText,
              hintStyle: AppTextStyles.medium.copyWith(
                fontSize: 14,
                color: Colors.black.withAlpha(52),
              ),
              contentPadding: const EdgeInsets.symmetric(
                vertical: 16,
                horizontal: 12,
              ),
              filled: true,
              fillColor: Colors.white,
              suffixIcon: suffix == null
                  ? null
                  : Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: suffix,
                    ),
              enabledBorder: OutlineInputBorder(
                borderRadius: .circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: .circular(12),
                borderSide: widget.readOnly
                    ? BorderSide.none
                    : BorderSide(color: Colors.blue),
              ),
            ),
          ),
        ).paddingOnly(top: 12),
      ],
    );
  }
}
