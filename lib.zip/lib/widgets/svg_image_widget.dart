import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class SvgImageWidget extends StatelessWidget {
  final String asset;
  final double? height;
  final double? width;
  final Color? color;
  final BoxFit fit;

  const SvgImageWidget({
    super.key,
    required this.asset,
    this.height,
    this.width,
    this.color,
    this.fit = BoxFit.contain,
  });

  @override
  Widget build(BuildContext context) => SvgPicture.asset(
    asset,
    height: height,
    width: width,
    colorFilter: color != null
        ? ColorFilter.mode(color!, BlendMode.srcIn)
        : null,
    fit: fit,
  );
}
