import 'package:game_app/module/game/view/game_screen.dart';
import 'package:game_app/routes/app_routes.dart';
import 'package:get/get.dart';

abstract final class AppPages {
  static const String initialRoute = Routes.gameScreen;

  static final List<GetPage<dynamic>> routes = [
    GetPage(name: Routes.gameScreen, page: () => const GameScreen()),
  ];
}
