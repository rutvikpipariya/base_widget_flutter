import 'package:flutter/material.dart';
import 'package:game_app/utils/color_extension.dart';

abstract final class AppColors {
  static Color get seed => '5C6BC0'.toColor();
  static Color get boardBackground => '263238'.toColor();
  static Color get hintText => '607D8B'.toColor();
  static Color get tileTextDark => '37474F'.toColor();
  static Color get white => 'FFFFFF'.toColor();
  static Color get black => '000000'.toColor();
  static Color get tile2 => 'EEEEEE'.toColor();
  static Color get tile4 => 'BBDEFB'.toColor();
  static Color get tile8 => '64B5F6'.toColor();
  static Color get tile16 => '66BB6A'.toColor();
  static Color get tile32 => 'FFA726'.toColor();
  static Color get tile64 => 'EF5350'.toColor();
  static Color get tile128 => 'AB47BC'.toColor();
  static Color get tile256 => 'F06292'.toColor();
  static Color get tile512 => '26A69A'.toColor();
  static Color get tile1024Plus => 'FFD54F'.toColor();

  static Color tileForValue(int value) {
    return switch (value) {
      2 => tile2,
      4 => tile4,
      8 => tile8,
      16 => tile16,
      32 => tile32,
      64 => tile64,
      128 => tile128,
      256 => tile256,
      512 => tile512,
      _ when value >= 1024 => tile1024Plus,
      _ => tile2,
    };
  }

  static Color textForTileValue(int value) {
    if (value <= 4) {
      return tileTextDark;
    }
    return white;
  }

  static Color selectionGlowForValue(int value) {
    return tileForValue(value).withValues(alpha: 0.65);
  }

  static Color shadowLight({double alpha = 0.12}) {
    return black.withValues(alpha: alpha);
  }

  static Color shadowMedium({double alpha = 0.2}) {
    return black.withValues(alpha: alpha);
  }

  static Color shadowSoft({double alpha = 0.06}) {
    return black.withValues(alpha: alpha);
  }

  static Color whiteOverlay({double alpha = 0.95}) {
    return white.withValues(alpha: alpha);
  }
}
