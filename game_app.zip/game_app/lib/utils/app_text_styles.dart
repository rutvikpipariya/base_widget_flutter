import 'package:flutter/material.dart';

abstract final class AppTextStyles {
  static TextStyle regular(BuildContext context) {
    return Theme.of(context).textTheme.bodyMedium ?? const TextStyle();
  }

  static TextStyle medium(BuildContext context) {
    return regular(context).copyWith(fontWeight: FontWeight.w500);
  }

  static TextStyle semibold(BuildContext context) {
    return regular(context).copyWith(fontWeight: FontWeight.w600);
  }

  static TextStyle bold(BuildContext context) {
    return regular(context).copyWith(fontWeight: FontWeight.w700);
  }
}
