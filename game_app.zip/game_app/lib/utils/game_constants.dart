abstract final class GameConstants {
  static const int boardSize = 5;
  static const int minChainLength = 2;
  static const double tileSpacing = 6;
  static const double boardPadding = 16;
  static const double tileBorderRadius = 12;
  static const double boardBorderRadius = 16;
  static const double selectedTileScale = 1.08;
  static const Duration selectionAnimationDuration = Duration(
    milliseconds: 150,
  );
  static const Duration mergeAnimationDuration = Duration(milliseconds: 280);
  static const Duration gravityAnimationDuration = Duration(milliseconds: 220);
  static const Duration spawnAnimationDuration = Duration(milliseconds: 200);
  static const Duration popAnimationDuration = Duration(milliseconds: 180);
  static const Duration scoreAnimationDuration = Duration(milliseconds: 400);
  static const double spawnProbability2 = 0.70;
  static const double spawnProbability4 = 0.25;
  static const double spawnProbability8 = 0.05;
}
