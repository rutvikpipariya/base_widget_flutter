import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:game_app/module/game/model/tile.dart';

extension BoardPositionExtension on Offset {
  (int row, int col) toBoardCell({
    required double cellSize,
    required int boardSize,
  }) {
    final col = (dx / cellSize).floor().clamp(0, boardSize - 1);
    final row = (dy / cellSize).floor().clamp(0, boardSize - 1);
    return (row, col);
  }
}

extension TileListExtension on List<Tile> {
  bool get isValidChainLength => length >= 2;

  Set<String> get ids => map((tile) => tile.id).toSet();
}

extension IntFormatting on int {
  String get formattedScore => toString();

  Offset cellCenter({
    required double cellSize,
    required double spacing,
    required int row,
    required int col,
  }) {
    final stride = cellSize + spacing;
    return Offset(col * stride + cellSize / 2, row * stride + cellSize / 2);
  }
}

extension MathClamp on num {
  double clampDouble(double min, double max) =>
      math.max(min, math.min(max, toDouble()));
}
