import 'package:game_app/module/game/model/tile.dart';

class MergeAnimationData {
  const MergeAnimationData({
    required this.chain,
    required this.targetRow,
    required this.targetColumn,
    required this.mergedValue,
    required this.consumedTileIds,
    required this.survivingTileId,
  });

  final List<Tile> chain;
  final int targetRow;
  final int targetColumn;
  final int mergedValue;
  final List<String> consumedTileIds;
  final String survivingTileId;
}

class GravityMoveData {
  const GravityMoveData({
    required this.tileId,
    required this.fromRow,
    required this.toRow,
    required this.column,
  });

  final String tileId;
  final int fromRow;
  final int toRow;
  final int column;

  int get rowDelta => toRow - fromRow;
}

class SpawnData {
  const SpawnData({required this.tile});

  final Tile tile;
}
