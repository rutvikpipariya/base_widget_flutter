class Tile {
  const Tile({
    required this.value,
    required this.row,
    required this.column,
    required this.id,
    this.selected = false,
    this.isAnimating = false,
  });

  final int value;
  final int row;
  final int column;
  final bool selected;
  final String id;
  final bool isAnimating;

  Tile copyWith({
    int? value,
    int? row,
    int? column,
    bool? selected,
    String? id,
    bool? isAnimating,
  }) {
    return Tile(
      value: value ?? this.value,
      row: row ?? this.row,
      column: column ?? this.column,
      selected: selected ?? this.selected,
      id: id ?? this.id,
      isAnimating: isAnimating ?? this.isAnimating,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Tile &&
          value == other.value &&
          row == other.row &&
          column == other.column &&
          selected == other.selected &&
          id == other.id &&
          isAnimating == other.isAnimating;

  @override
  int get hashCode =>
      Object.hash(value, row, column, selected, id, isAnimating);

  @override
  String toString() =>
      'Tile(value: $value, row: $row, col: $column, id: $id, selected: $selected)';
}

typedef Board = List<List<Tile?>>;
