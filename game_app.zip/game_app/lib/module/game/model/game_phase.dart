enum GamePhase { idle, merging, falling, spawning }
