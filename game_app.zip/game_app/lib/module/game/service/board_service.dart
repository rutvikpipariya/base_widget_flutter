import 'dart:math';

import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/module/game/service/random_service.dart';
import 'package:game_app/utils/game_constants.dart';

class BoardService {
  BoardService({RandomService? randomService})
    : randomService = randomService ?? RandomService(),
      random = Random();

  final RandomService randomService;
  final Random random;
  int idCounter = 0;

  Board cloneBoard(Board board) {
    return List.generate(
      GameConstants.boardSize,
      (row) => List<Tile?>.from(board[row]),
    );
  }

  Board generateBoard() {
    idCounter = 0;
    return List.generate(
      GameConstants.boardSize,
      (row) => List<Tile?>.generate(
        GameConstants.boardSize,
        (col) => buildTile(
          value: randomService.randomSpawnValue(),
          row: row,
          column: col,
        ),
      ),
    );
  }

  Tile? tileAt(Board board, int row, int column) {
    if (!isInsideBoard(row, column)) {
      return null;
    }
    return board[row][column];
  }

  Board replaceTile(Board board, int row, int column, Tile? tile) {
    final next = cloneBoard(board);
    next[row][column] = tile;
    return next;
  }

  bool isInsideBoard(int row, int column) {
    return row >= 0 &&
        row < GameConstants.boardSize &&
        column >= 0 &&
        column < GameConstants.boardSize;
  }

  bool areNeighbors((int row, int col) a, (int row, int col) b) {
    final rowDelta = (a.$1 - b.$1).abs();
    final colDelta = (a.$2 - b.$2).abs();
    return rowDelta <= 1 && colDelta <= 1 && (rowDelta + colDelta) > 0;
  }

  Tile? tileAtPosition(
    Board board, {
    required double localX,
    required double localY,
    required double cellSize,
    required double spacing,
  }) {
    final cell = resolvePointerCell(
      localX: localX,
      localY: localY,
      cellSize: cellSize,
      spacing: spacing,
    );
    return tileAt(board, cell.$1, cell.$2);
  }

  (int row, int col) pointerToCell({
    required double localX,
    required double localY,
    required double cellSize,
    required double spacing,
  }) {
    return resolvePointerCell(
      localX: localX,
      localY: localY,
      cellSize: cellSize,
      spacing: spacing,
    );
  }

  bool isBoardFull(Board board) {
    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        if (board[row][col] == null) {
          return false;
        }
      }
    }
    return true;
  }

  bool hasMergeableNeighbors(Board board) {
    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        final tile = board[row][col];
        if (tile == null) {
          continue;
        }
        for (final neighbor in neighborCoords(row, col)) {
          final other = board[neighbor.$1][neighbor.$2];
          if (other != null && other.value == tile.value) {
            return true;
          }
        }
      }
    }
    return false;
  }

  int highestTileValue(Board board) {
    var highest = 0;
    for (final row in board) {
      for (final tile in row) {
        if (tile != null && tile.value > highest) {
          highest = tile.value;
        }
      }
    }
    return highest;
  }

  Tile createTile({
    required int value,
    required int row,
    required int column,
    bool selected = false,
    bool isAnimating = false,
  }) {
    return buildTile(
      value: value,
      row: row,
      column: column,
      selected: selected,
      isAnimating: isAnimating,
    );
  }

  Tile buildTile({
    required int value,
    required int row,
    required int column,
    bool selected = false,
    bool isAnimating = false,
  }) {
    idCounter++;
    return Tile(
      value: value,
      row: row,
      column: column,
      id: 'tile_${idCounter}_${random.nextInt(1 << 20)}',
      selected: selected,
      isAnimating: isAnimating,
    );
  }

  (int row, int col) resolvePointerCell({
    required double localX,
    required double localY,
    required double cellSize,
    required double spacing,
  }) {
    final stride = cellSize + spacing;
    final col = (localX / stride).floor().clamp(0, GameConstants.boardSize - 1);
    final row = (localY / stride).floor().clamp(0, GameConstants.boardSize - 1);
    return (row, col);
  }

  List<(int, int)> neighborCoords(int row, int col) {
    const deltas = [
      (-1, 0),
      (1, 0),
      (0, -1),
      (0, 1),
      (-1, -1),
      (-1, 1),
      (1, -1),
      (1, 1),
    ];
    return deltas
        .map((d) => (row + d.$1, col + d.$2))
        .where((pos) => isInsideBoard(pos.$1, pos.$2))
        .toList();
  }
}
