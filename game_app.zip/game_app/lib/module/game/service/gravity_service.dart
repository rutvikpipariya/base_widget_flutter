import 'package:game_app/module/game/model/animation_data.dart';
import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/module/game/service/board_service.dart';
import 'package:game_app/utils/game_constants.dart';

class GravityService {
  GravityService({BoardService? boardService})
    : boardService = boardService ?? BoardService();

  final BoardService boardService;

  ({Board board, List<GravityMoveData> moves}) applyGravity(Board board) {
    final next = boardService.cloneBoard(board);
    final moves = <GravityMoveData>[];

    for (var col = 0; col < GameConstants.boardSize; col++) {
      var writeRow = GameConstants.boardSize - 1;

      for (var row = GameConstants.boardSize - 1; row >= 0; row--) {
        final tile = next[row][col];
        if (tile == null) {
          continue;
        }

        if (row != writeRow) {
          moves.add(
            GravityMoveData(
              tileId: tile.id,
              fromRow: row,
              toRow: writeRow,
              column: col,
            ),
          );
          next[writeRow][col] = tile.copyWith(row: writeRow, column: col);
          next[row][col] = null;
        }
        writeRow--;
      }
    }

    return (board: next, moves: moves);
  }
}
