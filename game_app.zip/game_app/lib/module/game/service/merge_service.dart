import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/module/game/service/board_service.dart';
import 'package:game_app/utils/extensions.dart';
import 'package:game_app/utils/game_constants.dart';

class MergeResult {
  const MergeResult({
    required this.board,
    required this.mergedValue,
    required this.survivingTile,
    required this.consumedTileIds,
  });

  final Board board;
  final int mergedValue;
  final Tile survivingTile;
  final List<String> consumedTileIds;
}

class MergeService {
  MergeService({BoardService? boardService})
    : boardService = boardService ?? BoardService();

  final BoardService boardService;

  bool canExtendChain({
    required List<Tile> chain,
    required Tile candidate,
    required Board board,
  }) {
    if (chain.isEmpty) {
      return true;
    }

    if (chain.ids.contains(candidate.id)) {
      return false;
    }

    final last = chain.last;
    final isSameValue = candidate.value == last.value;
    final isNextPower = candidate.value == last.value * 2;

    if (!isSameValue && !isNextPower) {
      return false;
    }

    if (isNextPower && !canAddNextPower(chain, last)) {
      return false;
    }

    if (!boardService.areNeighbors(
      (last.row, last.column),
      (candidate.row, candidate.column),
    )) {
      return false;
    }

    final live = boardService.tileAt(board, candidate.row, candidate.column);
    return live?.id == candidate.id;
  }

  bool canAddNextPower(List<Tile> chain, Tile last) {
    final countOfLast = chain.where((tile) => tile.value == last.value).length;
    if (countOfLast >= 2) {
      return true;
    }
    return last.value > chain.first.value;
  }

  bool isUniformChain(List<Tile> chain) {
    if (chain.isEmpty) {
      return true;
    }
    final firstValue = chain.first.value;
    return chain.every((tile) => tile.value == firstValue);
  }

  int calculateMergedValue(int baseValue, int chainLength) {
    assert(chainLength >= GameConstants.minChainLength);
    var result = baseValue;
    for (var i = 1; i < chainLength; i++) {
      result *= 2;
    }
    return result;
  }

  int calculateMergedValueForChain(List<Tile> chain) {
    assert(chain.length >= GameConstants.minChainLength);

    if (isUniformChain(chain)) {
      return calculateMergedValue(chain.first.value, chain.length);
    }

    final highest = chain
        .map((tile) => tile.value)
        .reduce((a, b) => a > b ? a : b);
    return highest * 2;
  }

  MergeResult applyMerge(Board board, List<Tile> chain) {
    if (chain.length < GameConstants.minChainLength) {
      throw ArgumentError('Chain too short to merge');
    }

    final next = boardService.cloneBoard(board);
    final survivor = chain.last;
    final mergedValue = calculateMergedValueForChain(chain);
    final consumed = <String>[];

    for (var i = 0; i < chain.length - 1; i++) {
      final tile = chain[i];
      next[tile.row][tile.column] = null;
      consumed.add(tile.id);
    }

    final updatedSurvivor = survivor.copyWith(
      value: mergedValue,
      selected: false,
      isAnimating: false,
    );
    next[survivor.row][survivor.column] = updatedSurvivor;

    return MergeResult(
      board: next,
      mergedValue: mergedValue,
      survivingTile: updatedSurvivor,
      consumedTileIds: consumed,
    );
  }
}
