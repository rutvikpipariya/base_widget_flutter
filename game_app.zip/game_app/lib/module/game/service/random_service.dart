import 'dart:math';

import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/utils/game_constants.dart';

class RandomService {
  RandomService({Random? random}) : random = random ?? Random();

  final Random random;

  int randomSpawnValue() {
    final roll = random.nextDouble();
    if (roll < GameConstants.spawnProbability2) {
      return 2;
    }
    if (roll <
        GameConstants.spawnProbability2 + GameConstants.spawnProbability4) {
      return 4;
    }
    return 8;
  }

  List<Tile> fillEmptyCells(
    Board board,
    Tile Function(int value, int row, int col) createTile,
  ) {
    final spawns = <Tile>[];
    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        if (board[row][col] == null) {
          final tile = createTile(randomSpawnValue(), row, col);
          board[row][col] = tile;
          spawns.add(tile);
        }
      }
    }
    return spawns;
  }
}
