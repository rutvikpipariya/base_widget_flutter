import 'package:flutter/material.dart';
import 'package:game_app/module/game/view/stat_card.dart';
import 'package:game_app/utils/extensions.dart';
import 'package:game_app/utils/game_constants.dart';

class ScoreWidget extends StatefulWidget {
  const ScoreWidget({
    super.key,
    required this.score,
    required this.highestTile,
  });

  final int score;
  final int highestTile;

  @override
  State<ScoreWidget> createState() => ScoreWidgetState();
}

class ScoreWidgetState extends State<ScoreWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController pulseController;
  int displayedScore = 0;

  @override
  void initState() {
    super.initState();
    displayedScore = widget.score;
    pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
  }

  @override
  void didUpdateWidget(covariant ScoreWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.score != oldWidget.score) {
      pulseController.forward(from: 0);
    }
  }

  @override
  void dispose() {
    pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<int>(
      tween: IntTween(begin: displayedScore, end: widget.score),
      duration: GameConstants.scoreAnimationDuration,
      curve: Curves.easeOut,
      onEnd: () => displayedScore = widget.score,
      builder: (context, animatedScore, child) {
        return ScaleTransition(
          scale: Tween<double>(begin: 1, end: 1.08).animate(
            CurvedAnimation(parent: pulseController, curve: Curves.easeOut),
          ),
          child: Row(
            mainAxisAlignment: .spaceEvenly,
            children: [
              StatCard(
                label: 'Score',
                value: animatedScore.formattedScore,
                icon: Icons.star_rounded,
              ),
              StatCard(
                label: 'Best Tile',
                value: '${widget.highestTile}',
                icon: Icons.emoji_events_rounded,
              ),
            ],
          ),
        );
      },
    );
  }
}
