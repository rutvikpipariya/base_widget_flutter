import 'package:flutter/material.dart';
import 'package:game_app/module/game/controller/game_controller.dart';
import 'package:game_app/module/game/model/animation_data.dart';
import 'package:game_app/module/game/model/game_phase.dart';
import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/module/game/painter/connection_painter.dart';
import 'package:game_app/module/game/view/tile_widget.dart';
import 'package:game_app/utils/app_colors.dart';
import 'package:game_app/utils/game_constants.dart';

class BoardWidget extends StatefulWidget {
  const BoardWidget({
    super.key,
    required this.controller,
    required this.phase,
    required this.selectionLength,
  });

  final GameController controller;
  final GamePhase phase;
  final int selectionLength;

  @override
  State<BoardWidget> createState() => BoardWidgetState();
}

class BoardWidgetState extends State<BoardWidget>
    with TickerProviderStateMixin {
  late final AnimationController mergeController;
  late final AnimationController gravityController;
  late final AnimationController spawnController;
  late final AnimationController connectionController;
  late final AnimationController popController;

  GamePhase lastPhase = GamePhase.idle;
  int lastSelectionLength = 0;

  @override
  void initState() {
    super.initState();
    mergeController = AnimationController(
      vsync: this,
      duration: GameConstants.mergeAnimationDuration,
    )..addStatusListener(onMergeStatus);

    gravityController = AnimationController(
      vsync: this,
      duration: GameConstants.gravityAnimationDuration,
    )..addStatusListener(onGravityStatus);

    spawnController = AnimationController(
      vsync: this,
      duration: GameConstants.spawnAnimationDuration,
    )..addStatusListener(onSpawnStatus);

    connectionController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );

    popController = AnimationController(
      vsync: this,
      duration: GameConstants.popAnimationDuration,
    );

    lastPhase = widget.phase;
    lastSelectionLength = widget.selectionLength;
  }

  @override
  void didUpdateWidget(covariant BoardWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    handleControllerChanges();
  }

  void handleControllerChanges() {
    final controller = widget.controller;

    if (widget.phase == GamePhase.merging && lastPhase != GamePhase.merging) {
      mergeController.forward(from: 0);
      popController.forward(from: 0);
    }

    if (widget.phase == GamePhase.falling && lastPhase != GamePhase.falling) {
      if (controller.gravityMoves.isEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            widget.controller.onGravityAnimationComplete();
          }
        });
      } else {
        gravityController.forward(from: 0);
      }
    }

    if (widget.phase == GamePhase.spawning && lastPhase != GamePhase.spawning) {
      spawnController.forward(from: 0);
    }

    if (widget.selectionLength > lastSelectionLength) {
      connectionController.forward(from: 0);
    }

    lastPhase = widget.phase;
    lastSelectionLength = widget.selectionLength;
  }

  @override
  void dispose() {
    mergeController.dispose();
    gravityController.dispose();
    spawnController.dispose();
    connectionController.dispose();
    popController.dispose();
    super.dispose();
  }

  void onMergeStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      widget.controller.onMergeAnimationComplete();
    }
  }

  void onGravityStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      widget.controller.onGravityAnimationComplete();
    }
  }

  void onSpawnStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      widget.controller.onSpawnAnimationComplete();
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;

    return LayoutBuilder(
      builder: (context, constraints) {
        final spacing = GameConstants.tileSpacing;
        final maxBoardWidth =
            constraints.maxWidth - GameConstants.boardPadding * 2;
        final cellSize =
            (maxBoardWidth - spacing * (GameConstants.boardSize - 1)) /
            GameConstants.boardSize;

        controller.updateLayoutMetrics(cellSize: cellSize, spacing: spacing);

        final boardWidth =
            cellSize * GameConstants.boardSize +
            spacing * (GameConstants.boardSize - 1);
        final boardHeight = boardWidth;

        return Center(
          child: Container(
            padding: const EdgeInsets.all(GameConstants.boardPadding),
            decoration: BoxDecoration(
              color: AppColors.boardBackground,
              borderRadius: BorderRadius.circular(
                GameConstants.boardBorderRadius,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadowMedium(),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: GestureDetector(
              onPanStart: (details) =>
                  controller.onPanStart(details.localPosition),
              onPanUpdate: (details) =>
                  controller.onPanUpdate(details.localPosition),
              onPanEnd: (_) => controller.onPanEnd(),
              onPanCancel: controller.onPanCancel,
              child: SizedBox(
                width: boardWidth,
                height: boardHeight,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    ...buildTiles(
                      controller: controller,
                      cellSize: cellSize,
                      spacing: spacing,
                    ),
                    if (controller.selection.length >= 2 &&
                        controller.phase == GamePhase.idle)
                      AnimatedBuilder(
                        animation: connectionController,
                        builder: (context, _) {
                          return CustomPaint(
                            size: Size(boardWidth, boardHeight),
                            painter: ConnectionPainter(
                              points: controller.selectionCenters(
                                cellSize: cellSize,
                                spacing: spacing,
                              ),
                              color: AppColors.tileForValue(
                                controller.selection
                                    .map((tile) => tile.value)
                                    .reduce((a, b) => a > b ? a : b),
                              ),
                              strokeWidth: cellSize * 0.12,
                              progress: Curves.easeOut.transform(
                                connectionController.value,
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  List<Widget> buildTiles({
    required GameController controller,
    required double cellSize,
    required double spacing,
  }) {
    final widgets = <Widget>[];
    final stride = cellSize + spacing;
    final mergeData = controller.mergeAnimation;
    final mergeT = Curves.easeInOut.transform(mergeController.value);

    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        final tile = controller.board[row][col];
        if (tile == null) {
          continue;
        }

        if (controller.phase == GamePhase.merging &&
            mergeData != null &&
            mergeData.consumedTileIds.contains(tile.id) &&
            mergeT > 0.85) {
          continue;
        }

        final position = Offset(col * stride, row * stride);
        final gravityMatches = controller.gravityMoves.where(
          (move) => move.tileId == tile.id,
        );
        final gravityMove = gravityMatches.isEmpty
            ? null
            : gravityMatches.first;

        final translation = computeTranslation(
          tile: tile,
          mergeData: mergeData,
          gravityMove: gravityMove,
          phase: controller.phase,
          cellSize: cellSize,
          spacing: spacing,
          mergeT: mergeT,
          gravityT: Curves.easeIn.transform(gravityController.value),
        );

        final spawnMatches = controller.spawnData.where(
          (s) => s.tile.id == tile.id,
        );
        final spawnEntry = spawnMatches.isEmpty ? null : spawnMatches.first;

        final spawnT = Curves.elasticOut.transform(spawnController.value);
        final scale = computeScale(
          phase: controller.phase,
          spawnEntry: spawnEntry,
          spawnT: spawnT,
          popT: popController.value,
          isPopTarget: controller.popTileId == tile.id,
        );

        final opacity = computeOpacity(
          tile: tile,
          phase: controller.phase,
          mergeData: mergeData,
          mergeT: mergeT,
          spawnEntry: spawnEntry,
          spawnT: spawnT,
        );

        widgets.add(
          Positioned(
            left: position.dx,
            top: position.dy,
            width: cellSize,
            height: cellSize,
            child: TileWidget(
              tile: tile,
              size: cellSize,
              translation: translation,
              scale: scale,
              opacity: opacity,
            ),
          ),
        );
      }
    }

    return widgets;
  }

  Offset computeTranslation({
    required Tile tile,
    required MergeAnimationData? mergeData,
    required GravityMoveData? gravityMove,
    required GamePhase phase,
    required double cellSize,
    required double spacing,
    required double mergeT,
    required double gravityT,
  }) {
    final stride = cellSize + spacing;
    var translation = Offset.zero;

    if (phase == GamePhase.merging && mergeData != null) {
      if (mergeData.consumedTileIds.contains(tile.id)) {
        translation = Offset(
          (mergeData.targetColumn - tile.column) * stride * mergeT,
          (mergeData.targetRow - tile.row) * stride * mergeT,
        );
      }
    }

    if (phase == GamePhase.falling && gravityMove != null) {
      translation = Offset(0, gravityMove.rowDelta * stride * gravityT);
    }

    return translation;
  }

  double computeScale({
    required GamePhase phase,
    required SpawnData? spawnEntry,
    required double spawnT,
    required double popT,
    required bool isPopTarget,
  }) {
    if (phase == GamePhase.spawning && spawnEntry != null) {
      return 0.3 + 0.7 * spawnT;
    }

    if (phase == GamePhase.merging && isPopTarget) {
      if (popT < 0.5) {
        return 1 + 0.18 * (popT / 0.5);
      }
      return 1.18 - 0.18 * ((popT - 0.5) / 0.5);
    }

    return 1;
  }

  double computeOpacity({
    required Tile tile,
    required GamePhase phase,
    required MergeAnimationData? mergeData,
    required double mergeT,
    required SpawnData? spawnEntry,
    required double spawnT,
  }) {
    if (phase == GamePhase.merging &&
        mergeData != null &&
        mergeData.consumedTileIds.contains(tile.id)) {
      return 1 - mergeT;
    }

    if (phase == GamePhase.spawning && spawnEntry != null) {
      return spawnT.clamp(0, 1);
    }

    return 1;
  }
}
