import 'package:flutter/material.dart';
import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/utils/app_colors.dart';
import 'package:game_app/utils/app_text_styles.dart';
import 'package:game_app/utils/game_constants.dart';

class TileWidget extends StatelessWidget {
  const TileWidget({
    super.key,
    required this.tile,
    required this.size,
    this.translation = Offset.zero,
    this.scale = 1,
    this.opacity = 1,
  });

  final Tile tile;
  final double size;
  final Offset translation;
  final double scale;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    final backgroundColor = AppColors.tileForValue(tile.value);
    final textColor = AppColors.textForTileValue(tile.value);
    final isSelected = tile.selected;
    final effectiveScale = isSelected
        ? scale * GameConstants.selectedTileScale
        : scale;

    return RepaintBoundary(
      child: Opacity(
        opacity: opacity.clamp(0, 1),
        child: Transform.translate(
          offset: translation,
          child: Transform.scale(
            scale: effectiveScale,
            child: AnimatedContainer(
              duration: GameConstants.selectionAnimationDuration,
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(
                  GameConstants.tileBorderRadius,
                ),
                border: isSelected
                    ? Border.all(color: AppColors.whiteOverlay(), width: 3)
                    : null,
                boxShadow: [
                  BoxShadow(
                    color: isSelected
                        ? AppColors.selectionGlowForValue(tile.value)
                        : AppColors.shadowLight(),
                    blurRadius: isSelected ? 14 : 6,
                    spreadRadius: isSelected ? 2 : 0,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Text(
                      '${tile.value}',
                      style: AppTextStyles.bold(context).copyWith(
                        fontSize: fontSizeForValue(tile.value),
                        color: textColor,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  double fontSizeForValue(int value) {
    final digits = tile.value.toString().length;
    return switch (digits) {
      <= 2 => 28,
      3 => 24,
      4 => 20,
      _ => 16,
    };
  }
}
