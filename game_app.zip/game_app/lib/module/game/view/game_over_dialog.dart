import 'package:flutter/material.dart';
import 'package:game_app/utils/app_text_styles.dart';
import 'package:get/get.dart';

class GameOverDialog extends StatelessWidget {
  const GameOverDialog({
    super.key,
    required this.score,
    required this.highestTile,
    required this.onRestart,
  });

  final int score;
  final int highestTile;
  final VoidCallback onRestart;

  static Future<void> show(
    BuildContext context, {
    required int score,
    required int highestTile,
    required VoidCallback onRestart,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => GameOverDialog(
        score: score,
        highestTile: highestTile,
        onRestart: onRestart,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(
        children: [
          Icon(
            Icons.sports_esports_rounded,
            color: Theme.of(context).colorScheme.primary,
          ),
          Text(
            'Game Over',
            style: AppTextStyles.semibold(context),
          ).paddingOnly(left: 8),
        ],
      ),
      content: Column(
        mainAxisSize: .min,
        crossAxisAlignment: .start,
        children: [
          Text(
            'No more moves available.',
            style: AppTextStyles.regular(context).copyWith(fontSize: 16),
          ),
          GameOverResultRow(
            label: 'Score',
            value: '$score',
          ).paddingOnly(top: 20),
          GameOverResultRow(
            label: 'Highest Tile',
            value: '$highestTile',
          ).paddingOnly(top: 8),
        ],
      ),
      actions: [
        FilledButton.icon(
          onPressed: () {
            Navigator.of(context).pop();
            onRestart();
          },
          icon: const Icon(Icons.refresh_rounded),
          label: Text('Restart', style: AppTextStyles.medium(context)),
        ),
      ],
    );
  }
}

class GameOverResultRow extends StatelessWidget {
  const GameOverResultRow({
    super.key,
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: .spaceBetween,
      children: [
        Text(
          label,
          style: AppTextStyles.medium(context).copyWith(fontSize: 16),
        ),
        Text(
          value,
          style: AppTextStyles.bold(context).copyWith(
            fontSize: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      ],
    );
  }
}
