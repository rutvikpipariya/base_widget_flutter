import 'package:flutter/material.dart';
import 'package:game_app/module/game/controller/game_controller.dart';
import 'package:game_app/module/game/view/board_widget.dart';
import 'package:game_app/module/game/view/game_over_dialog.dart';
import 'package:game_app/module/game/view/score_widget.dart';
import 'package:game_app/utils/app_colors.dart';
import 'package:game_app/utils/app_text_styles.dart';
import 'package:get/get.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<GameController>(
      init: GameController(),
      builder: (controller) {
        if (controller.pendingGameOverDialog) {
          controller.onGameOverDialogShown();
          WidgetsBinding.instance.addPostFrameCallback((_) {
            GameOverDialog.show(
              context,
              score: controller.score,
              highestTile: controller.highestTile,
              onRestart: controller.restart,
            );
          });
        }

        return Scaffold(
          backgroundColor: Theme.of(context).colorScheme.surface,
          appBar: AppBar(
            title: Text('2248', style: AppTextStyles.semibold(context)),
            centerTitle: true,
            actions: [
              IconButton(
                tooltip: 'Restart',
                onPressed: controller.restart,
                icon: const Icon(Icons.refresh_rounded),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              crossAxisAlignment: .start,
              children: [
                ScoreWidget(
                  score: controller.score,
                  highestTile: controller.highestTile,
                ),
                Text(
                  'Link matching tiles, then climb: 2→2→4→8→16…',
                  style: AppTextStyles.regular(
                    context,
                  ).copyWith(fontSize: 14, color: AppColors.hintText),
                ).paddingOnly(top: 20),
                Expanded(
                  child: BoardWidget(
                    controller: controller,
                    phase: controller.phase,
                    selectionLength: controller.selection.length,
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: 16, vertical: 12),
          ),
        );
      },
    );
  }
}
