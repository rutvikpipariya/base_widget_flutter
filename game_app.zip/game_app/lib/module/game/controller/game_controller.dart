import 'package:flutter/material.dart';
import 'package:game_app/module/game/model/animation_data.dart';
import 'package:game_app/module/game/model/game_phase.dart';
import 'package:game_app/module/game/model/tile.dart';
import 'package:game_app/module/game/service/board_service.dart';
import 'package:game_app/module/game/service/gravity_service.dart';
import 'package:game_app/module/game/service/merge_service.dart';
import 'package:game_app/module/game/service/random_service.dart';
import 'package:game_app/utils/extensions.dart';
import 'package:game_app/utils/game_constants.dart';
import 'package:get/get.dart';

class GameController extends GetxController {
  GameController({
    BoardService? boardService,
    MergeService? mergeService,
    gravityService,
    RandomService? randomService,
  }) : boardService = boardService ?? BoardService(),
       mergeService = mergeService ?? MergeService(),
       gravityService = gravityService ?? GravityService(),
       randomService = randomService ?? RandomService();

  final BoardService boardService;
  final MergeService mergeService;
  final GravityService gravityService;
  final RandomService randomService;

  Board boardState = [];
  List<Tile> selectionList = [];
  int score = 0;
  int highestTile = 0;
  GamePhase phase = GamePhase.idle;
  bool isGameOver = false;
  bool pendingGameOverDialog = false;

  MergeAnimationData? mergeAnimation;
  List<GravityMoveData> gravityMoves = [];
  List<SpawnData> spawnData = [];
  String? popTileId;

  double cellSize = 0;
  double spacing = GameConstants.tileSpacing;

  Board get board => boardState;
  List<Tile> get selection => List.unmodifiable(selectionList);
  bool get canInteract => phase == GamePhase.idle && !isGameOver;

  @override
  void onInit() {
    super.onInit();
    startNewGame();
  }

  List<Offset> selectionCenters({
    required double cellSize,
    required double spacing,
  }) {
    return selectionList
        .map(
          (tile) => 0.cellCenter(
            cellSize: cellSize,
            spacing: spacing,
            row: tile.row,
            col: tile.column,
          ),
        )
        .toList();
  }

  void updateLayoutMetrics({
    required double cellSize,
    double spacing = GameConstants.tileSpacing,
  }) {
    this.cellSize = cellSize;
    this.spacing = spacing;
  }

  void onPanStart(Offset localPosition) {
    if (!canInteract || cellSize <= 0) {
      return;
    }

    final tile = tileAtPosition(localPosition);
    if (tile == null) {
      return;
    }

    selectionList
      ..clear()
      ..add(tile.copyWith(selected: true));
    syncSelectionOnBoard();
    update();
  }

  void onPanUpdate(Offset localPosition) {
    if (!canInteract || selectionList.isEmpty || cellSize <= 0) {
      return;
    }

    final tile = tileAtPosition(localPosition);
    if (tile == null) {
      return;
    }

    if (selectionList.last.id == tile.id) {
      return;
    }

    if (mergeService.canExtendChain(
      chain: selectionList,
      candidate: tile,
      board: boardState,
    )) {
      selectionList.add(tile.copyWith(selected: true));
      syncSelectionOnBoard();
      update();
    }
  }

  void onPanEnd() {
    if (!canInteract) {
      return;
    }

    if (selectionList.length < GameConstants.minChainLength) {
      clearSelection();
      update();
      return;
    }

    beginMerge();
  }

  void onPanCancel() {
    if (phase != GamePhase.idle) {
      return;
    }
    clearSelection();
    update();
  }

  void onMergeAnimationComplete() {
    if (phase != GamePhase.merging || mergeAnimation == null) {
      return;
    }

    final result = mergeService.applyMerge(boardState, mergeAnimation!.chain);
    boardState = result.board;
    score += result.mergedValue;
    highestTile = boardService
        .highestTileValue(boardState)
        .clamp(highestTile, 1 << 30);

    selectionList.clear();
    mergeAnimation = null;
    popTileId = null;

    beginGravity();
  }

  void onGravityAnimationComplete() {
    if (phase != GamePhase.falling) {
      return;
    }

    final gravityResult = gravityService.applyGravity(boardState);
    boardState = gravityResult.board;
    gravityMoves = [];

    beginSpawn();
  }

  void onSpawnAnimationComplete() {
    if (phase != GamePhase.spawning) {
      return;
    }

    spawnData = [];
    phase = GamePhase.idle;
    evaluateGameOver();
    update();
  }

  void restart() {
    pendingGameOverDialog = false;
    startNewGame();
    update();
  }

  void onGameOverDialogShown() {
    pendingGameOverDialog = false;
    update();
  }

  void startNewGame() {
    boardState = boardService.generateBoard();
    selectionList.clear();
    score = 0;
    highestTile = boardService.highestTileValue(boardState);
    phase = GamePhase.idle;
    isGameOver = false;
    mergeAnimation = null;
    gravityMoves = [];
    spawnData = [];
    popTileId = null;
  }

  void beginMerge() {
    final chain = List<Tile>.from(selectionList);
    final survivor = chain.last;
    final mergedValue = mergeService.calculateMergedValueForChain(chain);

    mergeAnimation = MergeAnimationData(
      chain: chain,
      targetRow: survivor.row,
      targetColumn: survivor.column,
      mergedValue: mergedValue,
      consumedTileIds: chain.take(chain.length - 1).map((t) => t.id).toList(),
      survivingTileId: survivor.id,
    );
    popTileId = survivor.id;
    phase = GamePhase.merging;

    boardState = boardService.cloneBoard(boardState);
    for (final tile in chain) {
      final current = boardState[tile.row][tile.column];
      if (current != null) {
        boardState[tile.row][tile.column] = current.copyWith(
          selected: true,
          isAnimating: true,
        );
      }
    }
    update();
  }

  void beginGravity() {
    final gravityResult = gravityService.applyGravity(boardState);
    gravityMoves = gravityResult.moves;
    phase = GamePhase.falling;
    update();
  }

  void beginSpawn() {
    final spawns = randomService.fillEmptyCells(
      boardState,
      (value, row, col) => boardService.createTile(
        value: value,
        row: row,
        column: col,
        isAnimating: true,
      ),
    );

    spawnData = spawns.map((tile) => SpawnData(tile: tile)).toList();
    highestTile = boardService
        .highestTileValue(boardState)
        .clamp(highestTile, 1 << 30);
    phase = GamePhase.spawning;
    update();
  }

  void evaluateGameOver() {
    if (boardService.isBoardFull(boardState) &&
        !boardService.hasMergeableNeighbors(boardState)) {
      isGameOver = true;
      pendingGameOverDialog = true;
      update();
    }
  }

  void clearSelection() {
    selectionList.clear();
    boardState = boardService.cloneBoard(boardState);
    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        final tile = boardState[row][col];
        if (tile != null && tile.selected) {
          boardState[row][col] = tile.copyWith(selected: false);
        }
      }
    }
  }

  void syncSelectionOnBoard() {
    boardState = boardService.cloneBoard(boardState);
    final selectedIds = selectionList.ids;
    for (var row = 0; row < GameConstants.boardSize; row++) {
      for (var col = 0; col < GameConstants.boardSize; col++) {
        final tile = boardState[row][col];
        if (tile != null) {
          boardState[row][col] = tile.copyWith(
            selected: selectedIds.contains(tile.id),
          );
        }
      }
    }
  }

  Tile? tileAtPosition(Offset localPosition) {
    return boardService.tileAtPosition(
      boardState,
      localX: localPosition.dx,
      localY: localPosition.dy,
      cellSize: cellSize,
      spacing: spacing,
    );
  }
}
