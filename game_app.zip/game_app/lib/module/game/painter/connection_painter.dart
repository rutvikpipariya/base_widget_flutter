import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

class ConnectionPainter extends CustomPainter {
  ConnectionPainter({
    required this.points,
    required this.color,
    this.strokeWidth = 10,
    this.progress = 1,
  });

  final List<Offset> points;
  final Color color;
  final double strokeWidth;
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) {
      return;
    }

    final path = buildSmoothPath(points);
    final metrics = path.computeMetrics().toList();
    if (metrics.isEmpty) {
      return;
    }

    final metric = metrics.first;
    final drawLength = metric.length * progress.clamp(0, 1);
    final extractPath = metric.extractPath(0, drawLength);

    final glowPaint = Paint()
      ..color = color.withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth + 6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    final linePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    canvas.drawPath(extractPath, glowPaint);
    canvas.drawPath(extractPath, linePaint);

    final nodePaint = Paint()..color = color.withValues(alpha: 0.9);
    for (final point in points) {
      canvas.drawCircle(point, strokeWidth / 2.2, nodePaint);
    }
  }

  Path buildSmoothPath(List<Offset> pts) {
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    if (pts.length == 2) {
      path.lineTo(pts.last.dx, pts.last.dy);
      return path;
    }

    for (var i = 0; i < pts.length - 1; i++) {
      final current = pts[i];
      final next = pts[i + 1];
      final mid = Offset(
        (current.dx + next.dx) / 2,
        (current.dy + next.dy) / 2,
      );
      path.quadraticBezierTo(current.dx, current.dy, mid.dx, mid.dy);
    }
    path.lineTo(pts.last.dx, pts.last.dy);
    return path;
  }

  @override
  bool shouldRepaint(ConnectionPainter oldDelegate) {
    return oldDelegate.points != points ||
        oldDelegate.color != color ||
        oldDelegate.strokeWidth != strokeWidth ||
        lerpDouble(oldDelegate.progress, progress, 1) != progress;
  }
}
