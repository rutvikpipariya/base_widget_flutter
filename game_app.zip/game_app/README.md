# Driver App

A Flutter-based driver application.

## Development Rules

When working on this project, follow these guidelines:

- **No refactor** — Do not restructure or rewrite existing code unless explicitly requested.
- **No major changes** — Keep scope limited to what is needed for the task at hand.
- **No inline comments** — Avoid adding inline comments in the code.
- **Minimal code changes** — Make the smallest change that solves the problem.
- **Follow existing patterns** — Match the current folder structure, naming conventions, and coding style used in the codebase.

## Strict Rules

These rules must be followed in all future changes and new features:

### Text Styles

- Always use `AppTextStyles` from `lib/utils/app_text_styles.dart` for text styling.
- Do not hardcode font family, font weight, or font size directly in widgets.
- Do not add new variants in `AppTextStyles`. Use existing styles (`regular`, `medium`, `semibold`, `bold`) and modify them with `.copyWith()` where needed (e.g. `AppTextStyles.regular(context).copyWith(fontSize: 14)`).

### Colors

- Never use hex colors, `Color(...)`, or `Colors.*` directly in screens, widgets, or controllers.
- Always define new colors first in `lib/utils/app_colors.dart`.
- Always define colors using hex strings with the `.toColor()` extension (e.g. `'8E8E93'.toColor()`).
- After adding a color in `AppColors`, reference it from `AppColors` wherever it is needed in the app.

### Folder Structure

All feature code lives under `lib/module/`. Each module gets its own folder with three subfolders: `controller`, `view`, and `model`.

Example for a **home** module:

```
lib/module/home/
├── controller/
│   └── home_controller.dart
├── view/
│   └── home_screen.dart
└── model/
    └── home_model.dart
```

- **`controller/`** — GetX controllers only (`GetxController`).
- **`view/`** — StatelessWidget screens only.
- **`model/`** — Dart models related to that module only.

When adding a new module, follow this structure. Do not mix files from different layers in the same folder.

### Routing

Always use `lib/routes/app_routes.dart` and `lib/routes/app_pages.dart` for navigation.

- **`app_routes.dart`** — Define route path constants in the `Routes` class (e.g. `Routes.homeScreen`).
- **`app_pages.dart`** — Register screens using `GetPage` in `AppPages.routes`.

When adding a new screen:

1. Add the route path constant in `app_routes.dart`.
2. Add the `GetPage` entry in `app_pages.dart`.
3. Navigate using `Get.toNamed(Routes.yourScreen)` or `Get.offNamed(Routes.yourScreen)`.

Do not define routes or navigation paths elsewhere in the app.

### Screen Structure

Every screen must be a `StatelessWidget` and follow this GetX pattern:

1. Wrap the screen with `GetBuilder<YourController>`.
2. Initialize the controller using `init: YourController()`.
3. Return the screen body inside `builder: (controller) { ... }`.
4. Keep all business logic in the controller, not in the screen.

```dart
class YourScreen extends StatelessWidget {
  const YourScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<YourController>(
      init: YourController(),
      builder: (controller) {
        return Scaffold(
          body: Center(
            child: YourWidget(
              onTap: () => controller.onAction(),
            ),
          ),
        );
      },
    );
  }
}
```

Rules:

- Do not use `Obx` anywhere inside screen files.
- Always use `GetBuilder` for state binding in screens, not `Obx` or `GetView`.
- Always pass `init: YourController()` inside `GetBuilder`.
- Screen files should only contain UI code. Navigation, API calls, and state logic belong in the controller.

### Controller Structure

All controllers must extend `GetxController` and use normal variables for state management.

```dart
class YourController extends GetxController {
  bool isLoading = false;
  String userName = '';

  void fetchData() async {
    isLoading = true;
    update();

    userName = 'John';
    isLoading = false;
    update();
  }
}
```

Rules:

- Do not use `.obs`, `Rx`, `RxBool`, `RxString`, `RxInt`, or any reactive GetX variables.
- Use normal Dart variables for all state (e.g. `bool`, `String`, `int`, `List`).
- Call `update()` after changing any variable that affects the UI.
- Keep navigation, API calls, and business logic inside the controller.

### Naming

- Do not use underscore (`_`) in variable, method, or function names.
- Use camelCase for variables, methods, and functions (e.g. `isLoading`, `fetchUserData`, `onButtonTap`).

### UI

- Always use Material 3 and the latest Material UI components for all screens.
- Use Material widgets on both Android and iOS. Do not use Cupertino widgets unless explicitly requested.
- Enable Material 3 in `ThemeData` using `useMaterial3: true`.
- Prefer latest Material components (e.g. `FilledButton`, `OutlinedButton`, `NavigationBar`, `NavigationDrawer`) over deprecated or legacy widgets.
- Keep UI consistent across Android and iOS using the same Material-based design system.

### Column & Row Alignment

Always use Dart's enum shorthand for `Column` and `Row` alignment properties. Do not write the full enum class prefix.

```dart
Column(
  crossAxisAlignment: .start,
  mainAxisAlignment: .start,
  mainAxisSize: .max,
  children: [...],
)

Row(
  crossAxisAlignment: .center,
  mainAxisAlignment: .spaceBetween,
  mainAxisSize: .min,
  children: [...],
)
```

- Use `.start`, `.end`, `.center`, `.spaceBetween`, `.spaceAround`, `.spaceEvenly`, `.min`, `.max`, `.stretch` etc.
- Never write `CrossAxisAlignment.start`, `MainAxisAlignment.center`, `MainAxisSize.max` or similar full prefixes.
- Apply the same shorthand to all Flutter enums wherever the type can be inferred (e.g. `MainAxisAlignment`, `CrossAxisAlignment`, `MainAxisSize`, `TextAlign`, `Axis`, etc.).

### Padding & Spacing

Always use GetX padding extensions for spacing. Do not use `SizedBox` for padding or spacing.

- Use `.paddingOnly()` for padding on specific sides (e.g. `.paddingOnly(top: 16)`).
- Use `.paddingSymmetric()` for horizontal or vertical padding (e.g. `.paddingSymmetric(horizontal: 16)`).
- Use `.padding()` for padding on all sides (e.g. `.padding(all: 16)`).

```dart
Column(
  children: [
    YourWidget(),
    YourWidget().paddingOnly(top: 16),
  ],
).paddingSymmetric(horizontal: 16)
```

## Project Layout (2248 Game)

```
lib/
├── main.dart
├── routes/
│   ├── app_routes.dart
│   └── app_pages.dart
├── utils/
│   ├── app_colors.dart
│   ├── app_text_styles.dart
│   ├── color_extension.dart
│   ├── extensions.dart
│   └── game_constants.dart
└── module/
    └── game/
        ├── controller/
        ├── model/
        ├── service/
        ├── painter/
        └── view/
```

## Getting Started

```bash
flutter pub get
flutter run
```
